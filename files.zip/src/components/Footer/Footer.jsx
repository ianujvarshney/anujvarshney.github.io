import React from "react";
import "./Footer.css";
import Wave from "../../img/wave.png";
import Twitter from "@iconscout/react-unicons/icons/uil-twitter";
import Linkedin from "@iconscout/react-unicons/icons/uil-linkedin";
import Gitub from "@iconscout/react-unicons/icons/uil-github";

const Footer = () => {
  return (
    <div className="footer">
      <img src={Wave} alt="" style={{ width: "100%" }} />
      <div className="f-content">
        {/* <span>Anuj@gmail.com</span> */}
        <div className="f-icons">
        <a href="https://twitter.com/iAnujVarshney"><Twitter color="white" size={"3rem"} /></a>
          <a href="https://www.linkedin.com/in/ianujvarshney" target="_blank"><Linkedin color="white" size={"3rem"} /></a>
          <a href="https://github.com/ianujvarshney" target="_blank"><Gitub color="white" size={"3rem"} /></a>
        </div>
      </div>
    </div>
  );
};

export default Footer;
