import React from "react";
import "./Footer.css";
import Twitter from "@iconscout/react-unicons/icons/uil-twitter";
import Linkedin from "@iconscout/react-unicons/icons/uil-linkedin";
import Gitub from "@iconscout/react-unicons/icons/uil-github";

const Footer = () => {
  return (
    <div className="footer">
      {/* Download */}
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#a767fe" fill-opacity="1" d="M0,64L120,85.3C240,107,480,149,720,154.7C960,160,1200,128,1320,112L1440,96L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path>
      </svg>
      {/* <img src={Wave} alt="" style={{ width: "100%" }} /> */}
      <div className="f-content">
        {/* <span>Anuj@gmail.com</span> */}
        <div className="f-icons">
          <a href="https://twitter.com/iAnujVarshney"><Twitter color="white" size={"3rem"} /></a>
          <a href="https://www.linkedin.com/in/ianujvarshney" target="_blank"><Linkedin color="white" size={"3rem"} /></a>
          <a href="https://github.com/ianujvarshney" target="_blank"><Gitub color="white" size={"3rem"} /></a>
        </div>
      </div>
    </div>
  );
};

export default Footer;
