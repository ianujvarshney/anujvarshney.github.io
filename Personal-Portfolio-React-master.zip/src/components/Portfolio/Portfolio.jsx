import React, { useContext } from "react";
import "./Portfolio.css";
import { Swiper, SwiperSlide } from "swiper/react"
import "swiper/css";
import iquincesoft from "../../img/iquincesoft.png";
import vejarano from "../../img/vejarano.png";
import HOC from "../../img/hoc.png";
import MusicApp from "../../img/musicapp.png";
import { themeContext } from "../../Context";
const Portfolio = () => {
  const theme = useContext(themeContext);
  const darkMode = theme.state.darkMode;
  return (
    <div className="portfolio" id="portfolio">
      {/* heading */}
      <span style={{color: darkMode?'white': ''}}>Worked Recent</span> <span>Projects</span>
      {/* slider */}
      <Swiper
        spaceBetween={30}
        slidesPerView={3} 
        grabCursor={true}
        loop={true}
        autoplay={2000}
        // speed={800}
        autoplayDisableOnInteraction={false}
        className="portfolio-slider"
      >
        <SwiperSlide>
          <a href="https://dev.iquincesoft.com/" target="_blank">
            <img src={iquincesoft} alt="" />
          </a>
        </SwiperSlide>
        <SwiperSlide>
          <a href="https://odontologiavejarano.com/" target="_blank">
            <img src={vejarano} alt="" />
          </a>
        </SwiperSlide>
        <SwiperSlide>
          <img src={MusicApp} alt="" />
        </SwiperSlide>
        <SwiperSlide>
          <img src={HOC} alt="" />
        </SwiperSlide>
      </Swiper>
    </div>
  );
};

export default Portfolio;
